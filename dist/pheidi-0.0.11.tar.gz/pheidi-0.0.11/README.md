# pheidi
High speed ring buffer messaging system using shared memory

See test.py for usage examples

Currently supports any data serializable by msgpack and msgpack_numpy

TODO:

Finish consumeb implementation

Add True safety using multiprocessing manager

MIT
