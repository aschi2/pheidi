# pheidi
High speed ring buffer messaging system using shared memory
